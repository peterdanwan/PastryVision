# pr_bakery > 2023-11-03 7:54am
https://universe.roboflow.com/project-hxki1/pr_bakery

Provided by a Roboflow user
License: CC BY 4.0

