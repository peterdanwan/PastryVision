# brv2 > 2023-05-18 1:24am
https://universe.roboflow.com/licenta-ntbhr/brv2

Provided by a Roboflow user
License: CC BY 4.0

